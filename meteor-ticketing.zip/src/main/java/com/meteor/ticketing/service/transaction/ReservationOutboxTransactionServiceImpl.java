package com.meteor.ticketing.service.transaction;

import com.meteor.ticketing.domain.entity.MqOutboxEvent;
import com.meteor.ticketing.domain.entity.TicketInventoryReservation;
import com.meteor.ticketing.enums.ReservationPersistResult;
import com.meteor.ticketing.service.IMqOutboxEventService;
import com.meteor.ticketing.service.ITicketInventoryReservationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *  保存订单库存扣除消息到数据库
 *
 * @author 昭兮
 * @version 1.0
 * @date 2026-08-17
 */
@Service
@RequiredArgsConstructor
public class ReservationOutboxTransactionServiceImpl
        implements ReservationOutboxTransactionService {

    private final ITicketInventoryReservationService reservationService;
    private final IMqOutboxEventService outboxService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void persist(
            TicketInventoryReservation reservation,
            MqOutboxEvent outboxEvent
    ) {
        ReservationPersistResult result =
                reservationService.persistPreReserved(reservation);

        if (result != ReservationPersistResult.CREATED) {
            throw new IllegalStateException(
                    "Reservation 创建结果异常: " + result
            );
        }

        outboxService.save(outboxEvent);
    }
}
